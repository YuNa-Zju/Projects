button = document.getElementById("form")
button.addEventListener('click', () => {
    boardColor = document.getElementById('boardColor').value;
    color_list[0] = document.getElementById('p1Color').value;
    color_list[1] = document.getElementById('p2Color').value;
    reset()
});