canvas = document.getElementById("myCanvas");
ctx = canvas.getContext("2d");
undoButton = document.getElementById("undoBtn")
redoButton = document.getElementById("redoBtn")
rule = document.getElementById("rule")
width = canvas.width
height = canvas.height
size = 30; // 六边形边长
hexCenters = [];
chesslist = [];
color_list = ["red", "blue", "transparent"]
current_color = 0
first_chess = 2
start_x = 100
start_y = 100
boardColor = "black";
columnLabels = ['A','B','C','D','E','F','G','H','I','J','K'];
record = []
redo = []
for(i = 0; i <= 11; i++)
{
    tmp = []
    for(j = 0; j <= 11; j++)
    {
        tmp.push(2)
    }
    chesslist.push(tmp)
}
function drawHexagon(centerX, centerY)
{
    ctx.beginPath();
    ctx.fillStyle = "black";
    ctx.font = "18px Arial";
    ctx.textAlign = "center";
    // 绘制行标签（1-11）和棋盘
    ctx.textAlign = "right";
    for (let i = 0; i < 6; i++)
        {
        var angle = Math.PI / 3 * i - Math.PI / 2;
        var x = centerX + size * Math.cos(angle);
        var y = centerY + size * Math.sin(angle);
        if (i === 0)
        {
            ctx.moveTo(x, y);
        }else
        {
            ctx.lineTo(x, y);
        }
    }
    ctx.closePath();
    ctx.strokeStyle = boardColor;
    ctx.lineWidth = 2;
    ctx.stroke();
}

function drawCircle(centerX, centerY, color)
{
    var radius = size / 1.5; // 圆的半径
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = color;
    ctx.fill();
}

function drawTriangle_h(x, y, direction, color) {
    // 计算三角形顶点坐标
    var topPoint = { x: x, y: y }; // 顶点
    var leftPoint = {
        x: x - d / 2,
        y: y + direction * size / 2  // Canvas坐标系Y轴向下
    };
    var rightPoint = {
        x: x + d / 2,
        y: y + direction * size / 2
    };

    // 绘制路径
    ctx.beginPath();
    ctx.moveTo(topPoint.x, topPoint.y);
    ctx.lineTo(leftPoint.x, leftPoint.y);
    ctx.lineTo(rightPoint.x, rightPoint.y);
    ctx.closePath();
    // ctx.strokeStyle = color
    // ctx.stroke();
    ctx.fillStyle = color;
    ctx.fill();
}

function drawTriangle_v(x, y, direction, color) {

    // 计算三角形顶点坐标
    var topPoint = { x: x, y: y }; // 顶点
    if(direction == -1)
    {
        var leftPoint = {
            x: x - d / 2,
            y: y - size / 2  // Canvas坐标系Y轴向下
        };
        var rightPoint = {
            x: x,
            y: y + size
        };
    }else
    {
        var leftPoint = {
            x: x,
            y: y - size  // Canvas坐标系Y轴向下
        };
        var rightPoint = {
            x: x + d / 2,
            y: y + size / 2
        };
    }


    // 绘制路径
    ctx.beginPath();
    ctx.moveTo(topPoint.x, topPoint.y);
    ctx.lineTo(leftPoint.x, leftPoint.y);
    ctx.lineTo(rightPoint.x, rightPoint.y);
    ctx.closePath();
    // ctx.strokeStyle = color
    // ctx.stroke();
    ctx.fillStyle = color;
    ctx.fill();
}
function drawBoard()
{
    x = start_x
    y = start_y
    d = size * Math.sqrt(3);
    ctx.fillStyle = "black";
    for (col = 0; col < 11; col++) {
        labelX = start_x + col * d + d/2 - size * Math.sqrt(3) / 2;
        drawTriangle_h(start_x - size * Math.sqrt(3) / 2 + (col) * d, start_y - size / 2, -1, color_list[0])
        ctx.fillStyle = "black";
        ctx.fillText(columnLabels[col], labelX, start_y - size * 2);
        drawTriangle_h(start_x + (col + 4) * d + 1.5 * d, start_y + 16 * size - size / 2 , 1, color_list[0])
    }

    for (row = 0; row < 11; row++) {
    // 计算行偏移量（每行向右偏移d/2）
        const rowOffset = row * d / 2;

        // 左边框（左侧三角形）
        const leftX = start_x - d + rowOffset + d / 2;
        const leftY = start_y + row * 1.5 * size;
        drawTriangle_v(leftX, leftY - size/2, -1, color_list[1]); // 方向参数-1表示向左

        // 右边框（右侧三角形）
        const rightX = start_x + 10 * d + rowOffset + d / 2; // 10 = 11列-1
        drawTriangle_v(rightX, leftY + size/2, 1, color_list[1]); // 方向参数1表示向右
    }

    ctx.fillStyle = "black";
    for(i = 1; i <= 11; i++)
    {
        ctx.fillText(i.toString(), start_x - size * 1.5 + (i - 1) * d / 2, y + 6);
        for(j = 1; j <= 11; j++)
        {
            drawHexagon(x + (j - 1) * d, y)
            hexCenters.push({x: x + (j - 1) * d, y: y});
        }
        x += d / 2
        y += 1.5 * size
    }
    for(i = 1; i <= 11; i++)
    {
        for(j = 1; j <= 11; j++)
        {
            if(chesslist[i][j] != 2)
            {
                chess_x = getHexCoordinate(i, j).x
                chess_y = getHexCoordinate(i, j).y
                drawCircle(chess_x, chess_y, color_list[chesslist[i][j]])
                // console.log(chess_x, chess_y)
            }
        }
    }
}

function getHexRowCol(hex) {
    x = hex.x
    y = hex.y
    var d = size * Math.sqrt(3);  // 列间距
    var rowHeight = 1.5 * size;   // 行高

    // 计算行号 (1-based)
    var row = Math.round((y - start_y) / rowHeight) + 1;

    // 计算该行起始X坐标
    var xStart = start_x + (row - 1) * d / 2;

    // 计算列号 (1-based)
    var col = Math.round((x - xStart) / d) + 1;

    return {
        row: Math.max(1, Math.min(11, row)),  // 限制在1-11
        col: Math.max(1, Math.min(11, col))   // 限制在1-11
    };
}

function getHexCoordinate(row, col) {
    var d = size * Math.sqrt(3);  // 列间距
    var rowHeight = 1.5 * size;   // 行高

    // 计算基础坐标
    var y = start_y + (row - 1) * rowHeight;
    var xStart = start_x + (row - 1) * d / 2;  // 行起始X坐标
    var x = xStart + (col - 1) * d;

    return {x: x, y: y};
}
function chess(chess_x, chess_y)
{
    if(chesslist[chess_x][chess_y] == 2)
    {
        record.push({x: chess_x, y: chess_y, color: current_color, swap: false, first_chess: first_chess})
        if(first_chess == 2 || first_chess == 1) first_chess--
        chesslist[chess_x][chess_y] = current_color
        current_color = 1 - current_color
    }else
    {
        if(first_chess == 1)
        {
            clr = chesslist[chess_x][chess_y]
            chesslist[chess_x][chess_y] = 2
            chesslist[chess_y][chess_x] = 1 - clr
            first_chess = 0
            record.push({x: chess_x, y: chess_y, color: current_color, swap: true, first_chess: 1})
            current_color = 1 - current_color
        }
    }
    redo = []
    moveDisplay()
}

canvas.addEventListener("mousedown", (event) => {
    var rect = canvas.getBoundingClientRect();
    var mouseX = event.clientX - rect.left;
    var mouseY = event.clientY - rect.top;

    let closestHex = null;
    let minDist = Infinity;

    // 遍历所有六边形中心，找到距离鼠标最近的一个
    for (var hex of hexCenters) {
        var dist = Math.sqrt((hex.x - mouseX) ** 2 + (hex.y - mouseY) ** 2);
        if (dist < minDist) {
            minDist = dist;
            closestHex = hex;
        }
    }

    // 判断点击是否在六边形内部（确保在边长范围内）
    if (minDist <= size) {
        chess_x = getHexRowCol(closestHex).row
        chess_y = getHexRowCol(closestHex).col
        chess(chess_x, chess_y)
    }
});

function moveDisplay(row, col) {
    text = ""
    for(_record of record)
    {
        if(!_record.swap)
            text += `玩家${_record.color+1} 落子于 ${String.fromCharCode(64+_record.y)}${_record.x}\n`;
        else
            text += "玩家2 使用首步交换原则\n"
    }
    for(i of [0, 1])
    {
        if(checkConnection(i))
        {
            text += `玩家${i+1} 赢了\n`;
        }
    }
    moveHistory.value = text;
    moveHistory.scrollTop = moveHistory.scrollHeight; // 自动滚动到底部
}

function Undo()
{
    if(record.length == 0) return;
    step = record.pop()
    if(!step.swap)
    {
        chesslist[step.x][step.y] = 2
        current_color = 1 - current_color
        first_chess = step.first_chess
    }else
    {
        chesslist[step.y][step.x] = 2
        chesslist[step.x][step.y] = 0
        current_color = 1 - current_color
        first_chess = step.first_chess
    }
    redo.push(step)
    moveDisplay()
}

function Redo()
{
    if(redo.length == 0) return;
    step = redo.pop()
    if(!step.swap)
    {
        chesslist[step.x][step.y] = step.color
        current_color = 1 - current_color
        first_chess = step.first_chess
    }else
    {
        chesslist[step.y][step.x] = 1
        chesslist[step.x][step.y] = 2
        current_color = 1 - current_color
    }
    if(first_chess != 0) first_chess--
    record.push(step)
    moveDisplay()
}

function reset()
{
    chesslist = []
    for(i = 0; i <= 11; i++)
    {
        tmp = []
        for(j = 0; j <= 11; j++)
        {
            tmp.push(2)
        }
        chesslist.push(tmp)
    }
    record = []
    redo = []
    first_chess = 2
    current_color = 0
    moveDisplay()
}

undoButton.addEventListener('click', Undo)
redoButton.addEventListener('click', Redo)
rule.addEventListener('click', () => {
    alert("Hex棋，又称Nash棋、六贯棋，最初在丹麦数学家海恩于1942年12月26日在丹麦报纸Politiken发表的一篇文章里出现，当时称为Polygon。1948年，约翰·福布斯·纳什重新独立发明了它。Hex棋的棋盘由六边形格子组成，形成一个菱形。两位玩家分别使用不同颜色的棋子进行对弈。目标是用自己的棋子连接棋盘的两个相对边，形成一条连续的路径。具体来说，一位玩家需要将棋盘的上下两边连接起来，另一位玩家则需要将左右两边连接起来。谁先完成这一目标，谁就获胜。\n\n\n  由于Hex存在显著的先手优势，所以引入首步交换原则，即第一步棋落子后，对方可选择将这颗棋子换成自己的棋子，并将其放到与原棋子位置关于棋盘对角线对称的位置上。先后手随机决定。")
})
function animate()
{
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBoard()
    requestAnimationFrame(animate);
}

animate();