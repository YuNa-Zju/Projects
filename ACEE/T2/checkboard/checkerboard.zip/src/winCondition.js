// 判断玩家是否连接对应边界的函数
function checkConnection(player) {//使用bfs检测赢家
    const rows = chesslist.length;
    const cols = chesslist[0].length;
    const visited = Array.from({ length: rows + 1 }, () =>
        Array(cols + 1).fill(false)
    );
    const queue = [];

    // 初始化队列 (根据玩家类型)
    if (player === 0) { // 上下边连接检测
        for (let col = 1; col < cols; col++) {
            if (chesslist[1][col] === player) {
                queue.push([1, col]);
                visited[1][col] = true;
            }
        }
    } else { // 左右边连接检测
        for (let row = 1; row < rows; row++) {
            if (chesslist[row][1] === player) {
                queue.push([row, 1]);
                visited[row][1] = true;
            }
        }
    }

    // 六边形相邻方向计算（考虑奇偶行偏移）
    const getNeighbors = (row, col) => {
        return [
            [row-1, col],    [row-1, col+1],  // 上方向
            [row,   col+1],                   // 右
            [row+1, col],    [row+1, col-1],  // 下方向
            [row,   col-1]                    // 左
        ]
    };

    while (queue.length > 0) {
        const [row, col] = queue.shift();

        // 胜利条件检查
        if (player === 0 && row === rows - 1) return true; // 到达下边界
        if (player === 1 && col === cols - 1) return true; // 到达右边界

        // 遍历所有相邻六边形
        for (var [nr, nc] of getNeighbors(row, col)) {
            if (nr >= 1 && nr < rows && nc >= 1 && nc < cols &&
                !visited[nr][nc] && chesslist[nr][nc] === player) {
                visited[nr][nc] = true;
                queue.push([nr, nc]);
            }
        }
    }
    return false;
}